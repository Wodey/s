from setuptools import find_packages, setup
setup(
    name='numerical_py',
    packages=find_packages(),
    version='1.0.0',
    description='Library for Numerical Methods Exam',
    author='Aleksey Malakhov',
    license='MIT',
)